import SwiftUI

@main
struct WidgetForgeApp: App {
    @StateObject private var library = DesignLibrary()

    var body: some Scene {
        WindowGroup {
            DesignLibraryView()
                .environmentObject(library)
                .onOpenURL { url in
                    library.handle(url: url)
                }
        }
    }
}
