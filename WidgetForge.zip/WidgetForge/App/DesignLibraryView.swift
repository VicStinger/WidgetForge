import SwiftUI

/// Home screen of the app: every design you've made, grouped by widget size.
struct DesignLibraryView: View {
    @EnvironmentObject private var library: DesignLibrary

    @State private var showNew = false
    @State private var showHelp = false
    @State private var showCredits = false
    @State private var renaming: WidgetDesign?
    @State private var renameText = ""
    @State private var pendingDelete: WidgetDesign?

    var body: some View {
        NavigationStack(path: $library.path) {
            Group {
                if library.designs.isEmpty {
                    emptyState
                } else {
                    gallery
                }
            }
            .navigationTitle("WidgetForge")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Menu {
                        Button {
                            showHelp = true
                        } label: {
                            Label("How it works", systemImage: "questionmark.circle")
                        }
                        Button {
                            showCredits = true
                        } label: {
                            Label("Credits", systemImage: "person.2")
                        }
                    } label: {
                        Image(systemName: "questionmark.circle")
                    }
                    .accessibilityLabel("Help and credits")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        showNew = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .navigationDestination(for: UUID.self) { id in
                if let design = library.design(id: id) {
                    EditorView(design: design, library: library)
                } else {
                    ContentUnavailableView("Widget not found", systemImage: "questionmark.square.dashed")
                }
            }
            .onAppear {
                library.reload()
            }
        }
        .sheet(isPresented: $showNew) {
            NewDesignView { design in
                library.path = [design.id]
            }
        }
        .sheet(isPresented: $showHelp) {
            HelpView()
        }
        .sheet(isPresented: $showCredits) {
            CreditsSheet()
        }
        .alert("Rename Widget", isPresented: renameBinding) {
            TextField("Name", text: $renameText)
            Button("Save") {
                if let design = renaming {
                    library.rename(design, to: renameText)
                }
                renaming = nil
            }
            Button("Cancel", role: .cancel) {
                renaming = nil
            }
        }
        .confirmationDialog(
            "Delete this widget?",
            isPresented: deleteBinding,
            titleVisibility: .visible,
            presenting: pendingDelete
        ) { design in
            Button("Delete \"\(design.name)\"", role: .destructive) {
                library.delete(design)
                pendingDelete = nil
            }
        } message: { _ in
            Text("Any Home Screen widget showing it will go blank.")
        }
    }

    // MARK: Bindings

    private var renameBinding: Binding<Bool> {
        Binding(
            get: { renaming != nil },
            set: { isPresented in
                if !isPresented { renaming = nil }
            }
        )
    }

    private var deleteBinding: Binding<Bool> {
        Binding(
            get: { pendingDelete != nil },
            set: { isPresented in
                if !isPresented { pendingDelete = nil }
            }
        )
    }

    // MARK: Empty state

    private var emptyState: some View {
        ContentUnavailableView {
            Label("No widgets yet", systemImage: "square.grid.2x2")
        } description: {
            Text("Design your own Home Screen widget from scratch with text, clocks, countdowns, progress rings and photos.")
        } actions: {
            Button("Create a Widget") {
                showNew = true
            }
            .buttonStyle(.borderedProminent)
            Button("How it works") {
                showHelp = true
            }
        }
    }

    // MARK: Gallery

    private var gallery: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                if !AppGroup.isAvailable {
                    setupWarning
                }
                ForEach(WidgetSize.allCases) { size in
                    section(for: size)
                }
            }
            .padding()
        }
        .background(Color(.systemGroupedBackground))
    }

    @ViewBuilder private func section(for size: WidgetSize) -> some View {
        let items = library.designs.filter { $0.size == size }
        if !items.isEmpty {
            VStack(alignment: .leading, spacing: 12) {
                Text("\(size.title) widgets")
                    .font(.title3.weight(.semibold))
                LazyVGrid(columns: columns(for: size), alignment: .leading, spacing: 20) {
                    ForEach(items) { design in
                        card(design)
                    }
                }
            }
        }
    }

    private func columns(for size: WidgetSize) -> [GridItem] {
        switch size {
        case .small:
            return [GridItem(.adaptive(minimum: 150, maximum: 220), spacing: 16)]
        case .medium, .large:
            return [GridItem(.adaptive(minimum: 300, maximum: 420), spacing: 16)]
        }
    }

    private func card(_ design: WidgetDesign) -> some View {
        NavigationLink(value: design.id) {
            VStack(alignment: .leading, spacing: 8) {
                DesignThumbnail(design: design)
                    .shadow(color: Color.black.opacity(0.18), radius: 8, x: 0, y: 4)
                Text(design.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(Color.primary)
                    .lineLimit(1)
                Text(design.elements.count == 1 ? "1 layer" : "\(design.elements.count) layers")
                    .font(.caption)
                    .foregroundStyle(Color.secondary)
            }
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button {
                library.path = [design.id]
            } label: {
                Label("Edit", systemImage: "slider.horizontal.3")
            }
            Button {
                library.duplicate(design)
            } label: {
                Label("Duplicate", systemImage: "plus.square.on.square")
            }
            Button {
                renameText = design.name
                renaming = design
            } label: {
                Label("Rename", systemImage: "pencil")
            }
            Button(role: .destructive) {
                pendingDelete = design
            } label: {
                Label("Delete", systemImage: "trash")
            }
        }
    }

    private var setupWarning: some View {
        Button {
            showHelp = true
        } label: {
            HStack(alignment: .top, spacing: 10) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .foregroundStyle(Color.orange)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Widgets can't see your designs yet")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(Color.primary)
                    Text("The App Group isn't set up for this build. Tap for the fix.")
                        .font(.footnote)
                        .foregroundStyle(Color.secondary)
                        .multilineTextAlignment(.leading)
                }
                Spacer()
            }
            .padding(12)
            .background(RoundedRectangle(cornerRadius: 12, style: .continuous).fill(Color.orange.opacity(0.14)))
        }
        .buttonStyle(.plain)
    }
}
